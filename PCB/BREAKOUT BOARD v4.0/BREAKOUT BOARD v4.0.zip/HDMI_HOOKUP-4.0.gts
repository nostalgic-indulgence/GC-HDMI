G04*
G04 Format:               Gerber RS-274X*
G04 Export Settings:      OSH Park*
G04 Layer:                TopSolderMask*
G04 This File Name:       HDMI_HOOKUP-4.0.gts*
G04 Source File Name:     HDMI_HOOKUP-3.0.rrb*
G04 Unique ID:            2af05bd5-e255-42dc-b699-2892e9971856*
G04 Generated Date:       Thursday, 20 July 2017 15:07:41*
G04*
G04 Created Using:        Robot Room Copper Connection v3.0.5875*
G04 Software Contact:     http://www.robotroom.com/CopperConnection/Support.aspx*
G04 License Number:       1880*
G04*
G04 Zero Suppression:     Leading*
G04 Number Precision:     2.4*
G04*
G04 Polarity:             Negative. Dark is solderable. Clear space is coating.*
G04*
%FSLAX24Y24*%
%MOIN*%
%LNTopSolderMask*%
%ADD10C,.07*%
%ADD11C,.0809*%
%ADD12C,.1281*%
%ADD13R,.006X.006*%
%ADD14R,.0494X.0789*%
D10*
G01X2798Y1422D03*
X3464D03*
X4131D03*
X4798D03*
X2798Y2422D03*
X3464D03*
X4131D03*
X4798D03*
X5464Y1422D03*
Y2422D03*
X6131Y1422D03*
Y2422D03*
X6797Y1422D03*
Y2422D03*
X7464Y1422D03*
Y2422D03*
X8130Y1422D03*
Y2422D03*
X8797Y1422D03*
Y2422D03*
X9463Y1422D03*
Y2422D03*
D11*
X4464Y3131D03*
X7797D03*
D12*
X10857Y1922D03*
X1404D03*
D14*
X1733Y4960D03*
X2324D03*
X2914D03*
X3505D03*
X4095D03*
X4686D03*
X5276D03*
X5867D03*
X6457D03*
X7048D03*
X8229D03*
X8820Y4962D03*
X9410Y4960D03*
X10001D03*
X10591D03*
X11182D03*
M02*
